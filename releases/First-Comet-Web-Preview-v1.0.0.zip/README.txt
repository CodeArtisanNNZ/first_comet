FIRST COMET — WEB PREVIEW v1.0.0

Take your project from first step to life.

HOW TO OPEN
1. Extract the ZIP file.
2. Double-click index.html.
3. Use a current Chrome, Edge or Firefox browser.

WHAT IS INCLUDED
- Animated First Comet introduction powered by Anime.js
- Project launchpad and local project creation
- Guided project studio and visual Git timeline
- Beginner build guide
- Language, database, hosting, Git and VS Code reference
- Light and dark themes
- Responsive desktop and mobile interface

IMPORTANT
This is the interactive browser preview. Browsers cannot directly modify arbitrary
computer folders or push to GitHub without additional desktop permissions and
GitHub authorization. Those operations belong in the upcoming desktop release.

Live preview:
https://first-comet-workspace.nusaibanusratz731891.chatgpt.site
